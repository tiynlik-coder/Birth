import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "DomiansBirthdayBot — Tug‘ilgan kun eslatmalari boti" },
      {
        name: "description",
        content:
          "DomiansBirthdayBot — tug‘ilgan kuningizni saqlang, shaxsiy eslatmalar yarating va Premium imkoniyatlardan foydalaning.",
      },
      { property: "og:title", content: "DomiansBirthdayBot — Tug‘ilgan kun boti" },
      {
        property: "og:description",
        content: "Telegram bot: tug‘ilgan kun saqlash, shaxsiy eslatmalar va Premium tarif.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const features = [
  { emoji: "🎂", title: "Tug‘ilgan kun qo‘shish", text: "Yil, oy va kunni bosqichma-bosqich tanlang." },
  { emoji: "✏️", title: "Tahrirlash", text: "Sanani istalgan vaqtda yangilang." },
  { emoji: "🔔", title: "Shaxsiy eslatma", text: "Premium foydalanuvchilar uchun o‘zgacha eslatma matni." },
  { emoji: "💎", title: "Premium tarif", text: "Atigi 10 000 so‘m — admin orqali faollashtiriladi." },
];

function Index() {
  return (
    <main className="min-h-screen bg-background px-5 py-14">
      <div className="mx-auto w-full max-w-md">
        <div className="text-center">
          <div className="mx-auto flex size-16 items-center justify-center rounded-3xl bg-primary text-3xl">
            🎂
          </div>
          <h1 className="mt-5 text-2xl font-bold tracking-tight text-foreground">DomiansBirthdayBot</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Tug‘ilgan kunlarni saqlang, eslatmalarni sozlang va Premium imkoniyatlardan foydalaning.
          </p>
          <a
            href="https://t.me/DomiansBirthdayBot"
            className="mt-6 inline-flex items-center justify-center rounded-xl bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
          >
            Telegramda ochish
          </a>
        </div>

        <section className="mt-10 space-y-3">
          {features.map((f) => (
            <article key={f.title} className="rounded-2xl border border-border bg-card p-4">
              <h2 className="text-sm font-semibold text-card-foreground">
                <span className="mr-2">{f.emoji}</span>
                {f.title}
              </h2>
              <p className="mt-1 text-sm text-muted-foreground">{f.text}</p>
            </article>
          ))}
        </section>

        <p className="mt-10 text-center text-xs text-muted-foreground">
          Savollar uchun:{" "}
          <a className="font-medium text-foreground" href="https://t.me/domians_admin">
            @domians_admin
          </a>
        </p>
      </div>
    </main>
  );
}
