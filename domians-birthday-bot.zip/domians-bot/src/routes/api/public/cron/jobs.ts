import { createFileRoute } from "@tanstack/react-router";
import { authenticateCronRequest } from "@/integrations/supabase/cron-auth";

type Job = "daily" | "life" | "birthday";

export const Route = createFileRoute("/api/public/cron/jobs")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const unauthorized = await authenticateCronRequest(request);
        if (unauthorized) return unauthorized;

        const url = new URL(request.url);
        let job = url.searchParams.get("job") as Job | null;
        let force = url.searchParams.get("force") === "1";
        if (!job) {
          try {
            const body = (await request.json()) as { job?: Job; force?: boolean };
            job = body.job ?? null;
            force = force || Boolean(body.force);
          } catch {
            /* no body */
          }
        }
        if (job !== "daily" && job !== "life" && job !== "birthday") {
          return Response.json({ ok: false, error: "unknown job" }, { status: 400 });
        }

        const scheduler = await import("@/lib/telegram/scheduler.server");
        try {
          const result =
            job === "daily"
              ? await scheduler.sendDailyReminders(force)
              : job === "life"
                ? await scheduler.sendLifeChecks()
                : await scheduler.sendBirthdayGreetings();
          return Response.json({ ok: true, ...result });
        } catch (error) {
          console.error(`[cron] ${job} failed`, error);
          return Response.json({ ok: false, error: String(error) }, { status: 500 });
        }
      },
    },
  },
});
