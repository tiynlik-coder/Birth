export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      birthdays: {
        Row: {
          birth_day: number
          birth_month: number
          birth_year: number
          created_at: string
          tg_id: number
          updated_at: string
        }
        Insert: {
          birth_day: number
          birth_month: number
          birth_year: number
          created_at?: string
          tg_id: number
          updated_at?: string
        }
        Update: {
          birth_day?: number
          birth_month?: number
          birth_year?: number
          created_at?: string
          tg_id?: number
          updated_at?: string
        }
        Relationships: []
      }
      bot_states: {
        Row: {
          data: Json
          message_id: number | null
          state: string | null
          tg_id: number
          updated_at: string
        }
        Insert: {
          data?: Json
          message_id?: number | null
          state?: string | null
          tg_id: number
          updated_at?: string
        }
        Update: {
          data?: Json
          message_id?: number | null
          state?: string | null
          tg_id?: number
          updated_at?: string
        }
        Relationships: []
      }
      bot_users: {
        Row: {
          created_at: string
          first_name: string | null
          last_name: string | null
          tg_id: number
          updated_at: string
          username: string | null
        }
        Insert: {
          created_at?: string
          first_name?: string | null
          last_name?: string | null
          tg_id: number
          updated_at?: string
          username?: string | null
        }
        Update: {
          created_at?: string
          first_name?: string | null
          last_name?: string | null
          tg_id?: number
          updated_at?: string
          username?: string | null
        }
        Relationships: []
      }
      broadcast_logs: {
        Row: {
          admin_id: number
          completed_at: string | null
          failed_count: number
          id: string
          message: Json | null
          sent_count: number
          started_at: string
        }
        Insert: {
          admin_id: number
          completed_at?: string | null
          failed_count?: number
          id?: string
          message?: Json | null
          sent_count?: number
          started_at?: string
        }
        Update: {
          admin_id?: number
          completed_at?: string | null
          failed_count?: number
          id?: string
          message?: Json | null
          sent_count?: number
          started_at?: string
        }
        Relationships: []
      }
      join_requests: {
        Row: {
          chat_id: number
          requested_at: string
          status: string
          tg_id: number
        }
        Insert: {
          chat_id: number
          requested_at?: string
          status?: string
          tg_id: number
        }
        Update: {
          chat_id?: number
          requested_at?: string
          status?: string
          tg_id?: number
        }
        Relationships: []
      }
      life_checks: {
        Row: {
          answer: string | null
          answered_at: string | null
          check_date: string
          created_at: string
          message_id: number | null
          tg_id: number
        }
        Insert: {
          answer?: string | null
          answered_at?: string | null
          check_date: string
          created_at?: string
          message_id?: number | null
          tg_id: number
        }
        Update: {
          answer?: string | null
          answered_at?: string | null
          check_date?: string
          created_at?: string
          message_id?: number | null
          tg_id?: number
        }
        Relationships: []
      }
      mandatory_chats: {
        Row: {
          active: boolean
          chat_id: number
          chat_type: string
          connected_at: string
          invite_link: string | null
          is_request_based: boolean
          title: string | null
          username: string | null
        }
        Insert: {
          active?: boolean
          chat_id: number
          chat_type: string
          connected_at?: string
          invite_link?: string | null
          is_request_based?: boolean
          title?: string | null
          username?: string | null
        }
        Update: {
          active?: boolean
          chat_id?: number
          chat_type?: string
          connected_at?: string
          invite_link?: string | null
          is_request_based?: boolean
          title?: string | null
          username?: string | null
        }
        Relationships: []
      }
      notification_log: {
        Row: {
          created_at: string
          kind: string
          send_date: string
          sent_at: string | null
          tg_id: number
        }
        Insert: {
          created_at?: string
          kind: string
          send_date: string
          sent_at?: string | null
          tg_id: number
        }
        Update: {
          created_at?: string
          kind?: string
          send_date?: string
          sent_at?: string | null
          tg_id?: number
        }
        Relationships: []
      }
      premium: {
        Row: {
          active: boolean
          granted_at: string | null
          granted_by: number | null
          revoked_at: string | null
          revoked_by: number | null
          selected_template_id: number | null
          tg_id: number
          updated_at: string
        }
        Insert: {
          active?: boolean
          granted_at?: string | null
          granted_by?: number | null
          revoked_at?: string | null
          revoked_by?: number | null
          selected_template_id?: number | null
          tg_id: number
          updated_at?: string
        }
        Update: {
          active?: boolean
          granted_at?: string | null
          granted_by?: number | null
          revoked_at?: string | null
          revoked_by?: number | null
          selected_template_id?: number | null
          tg_id?: number
          updated_at?: string
        }
        Relationships: []
      }
      reminders: {
        Row: {
          text: string
          tg_id: number
          updated_at: string
        }
        Insert: {
          text: string
          tg_id: number
          updated_at?: string
        }
        Update: {
          text?: string
          tg_id?: number
          updated_at?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
