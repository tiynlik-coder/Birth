/**
 * DomiansBirthdayBot — core update handling.
 * Server-only module.
 */
import { answerCallback, editMessage, sendMessage, tg, type InlineKeyboard } from "./api.server";
import {
  allUserIds,
  answerLifeCheck,
  countPremium,
  countUsers,
  finishBroadcast,
  getBirthday,
  getChat,
  getPremiumInfo,
  getPremiumRow,
  getState,
  grantPremium,
  hasJoinRequest,
  isPremium,
  listChats,
  listPremium,
  removeChat,
  revokePremium,
  saveBirthday,
  saveChat,
  saveJoinRequest,
  saveReminder,
  setSelectedTemplate,
  setState,
  startBroadcast,
  upsertUser,
} from "./db.server";
import {
  PREMIUM_TEMPLATES,
  renderReminderTemplate,
  tashkentDateString,
  tashkentToday,
} from "./templates.server";


export const ADMIN_ID = 5500951019;
const ADMIN_URL = "https://t.me/domians_admin";
const PREMIUM_PRICE = "10 000 so‘m";

const MONTHS = [
  "Yanvar",
  "Fevral",
  "Mart",
  "Aprel",
  "May",
  "Iyun",
  "Iyul",
  "Avgust",
  "Sentabr",
  "Oktabr",
  "Noyabr",
  "Dekabr",
];

const QUICK = {
  add: "🎂 Tug‘ilgan kun qo‘shish",
  edit: "✏️ Tug‘ilgan kunni tahrirlash",
  reminder: "📝 Eslatmani o‘zgartirish",
  templates: "🎨 Premium eslatmalar",
  premium: "💎 Premium tarif",
};

const quickKeyboard = {
  keyboard: [
    [{ text: QUICK.add }, { text: QUICK.edit }],
    [{ text: QUICK.reminder }, { text: QUICK.templates }],
    [{ text: QUICK.premium }],
  ],
  resize_keyboard: true,
  is_persistent: true,
};

const BACK: InlineKeyboard = [[{ text: "🔙 Ortga", callback_data: "menu" }]];

const WELCOME =
  "👋 <b>Assalomu alaykum!</b>\n\n" +
  "🎉 DomiansBirthdayBot ga xush kelibsiz!\n\n" +
  "🎂 Tug‘ilgan kuningizni saqlang, eslatmalardan foydalaning va kerakli funksiyalardan foydalaning.\n\n" +
  "✨ Xush kelibsiz!";

/* ------------------------------- helpers --------------------------------- */

function daysInMonth(year: number, month: number) {
  return new Date(year, month, 0).getDate();
}

function fmtDate(iso: string | null | undefined) {
  if (!iso) return { date: "-", time: "-" };
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, "0");
  return {
    date: `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`,
    time: `${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}`,
  };
}

/** Edit the user's active flow message; fall back to sending a new one. */
async function panel(chatId: number, text: string, keyboard?: InlineKeyboard) {
  const state = await getState(chatId);
  if (state.message_id) {
    const res = await editMessage(chatId, state.message_id, text, keyboard);
    if (res.ok) return;
    if (res.description?.includes("message is not modified")) return;
  }
  const sent = await sendMessage(chatId, text, keyboard);
  if (sent.ok && sent.result) {
    await setState(chatId, { message_id: sent.result.message_id });
  }
}

/**
 * Start a NEW flow message. The previous Welcome/Main message is left intact;
 * subsequent steps of this flow edit the message created here.
 */
async function openFlow(chatId: number, text: string, keyboard?: InlineKeyboard) {
  const sent = await sendMessage(chatId, text, keyboard);
  if (sent.ok && sent.result) {
    await setState(chatId, { message_id: sent.result.message_id });
  }
}

/** fresh=true → new message (quick action); fresh=false → edit current flow message. */
async function show(chatId: number, fresh: boolean, text: string, keyboard?: InlineKeyboard) {
  return fresh ? openFlow(chatId, text, keyboard) : panel(chatId, text, keyboard);
}


/* --------------------------- mandatory subscribe -------------------------- */

export async function checkSubscription(userId: number) {
  const chats = await listChats();
  // Check every chat in parallel — one slow Telegram call must not delay the rest.
  const results = await Promise.all(
    chats.map(async (chat) => {
      try {
        const checks: Promise<any>[] = [
          tg<{ status: string }>("getChatMember", { chat_id: Number(chat.chat_id), user_id: userId }),
        ];
        if (chat.is_request_based) checks.push(hasJoinRequest(Number(chat.chat_id), userId));
        const [member, requested] = await Promise.all(checks);
        const joined =
          member.ok && ["member", "administrator", "creator", "restricted"].includes(member.result?.status ?? "");
        return joined || (chat.is_request_based && requested) ? null : chat;
      } catch (error) {
        console.error("[subscription] check failed", error);
        return null;
      }
    }),
  );
  const missing = results.filter(Boolean);
  return { chats, missing, ok: missing.length === 0 };
}

/** Resolve a usable join URL for a mandatory chat, creating one if needed. */
async function chatJoinUrl(chat: any): Promise<string | null> {
  if (chat.invite_link) return String(chat.invite_link);
  if (chat.username) return `https://t.me/${String(chat.username).replace(/^@/, "")}`;
  const created = await tg<{ invite_link: string }>("createChatInviteLink", {
    chat_id: Number(chat.chat_id),
    name: "DomiansBirthdayBot",
  });
  if (created.ok && created.result?.invite_link) {
    const link = created.result.invite_link;
    try {
      const { db } = await import("./db.server");
      await db().from("mandatory_chats").update({ invite_link: link }).eq("chat_id", Number(chat.chat_id));
    } catch (error) {
      console.error("[subscription] failed to persist invite link", error);
    }
    return link;
  }
  console.error(
    `[subscription] no join url for chat ${chat.chat_id} (${chat.title ?? "-"}): ${created.description ?? "unknown"}`,
  );
  return null;
}

async function subscribeKeyboard(chats: any[]): Promise<InlineKeyboard> {
  const rows: InlineKeyboard = [];
  for (const chat of chats) {
    const url = await chatJoinUrl(chat);
    if (!url) continue;
    rows.push([{ text: `📢 Obuna bo‘lish — ${chat.title ?? chat.username ?? chat.chat_id}`, url }]);
  }
  if (rows.length === 0) {
    console.error("[subscription] no subscribe buttons could be built for", chats.length, "active chats");
    return [];
  }
  rows.push([{ text: "✅ Obuna bo‘ldim", callback_data: "sub:check" }]);
  return rows;
}

const SUB_TEXT =
  "👋 <b>Assalomu alaykum!</b> 🎉 DomiansBirthdayBot ga xush kelibsiz!\n\n" +
  "Botdan foydalanish uchun, iltimos, quyidagi kanallarimizga obuna bo‘ling.";

/* --------------------------------- menus ---------------------------------- */

async function showMain(chatId: number) {
  await panel(chatId, WELCOME);
}

async function premiumScreen(chatId: number, fresh = false) {
  const info = await getPremiumInfo(chatId);
  if (info.active) {
    return await show(
      chatId,
      fresh,
      "👑 <b>Siz Premium foydalanuvchisiz!</b>\n\n" +
        "⭐ Sizda barcha Premium imkoniyatlari faol:\n" +
        "📝 Shaxsiy eslatma matni\n" +
        "🎨 6 xil premium eslatma ko‘rinishi\n" +
        "🫶 Har kuni tiriklik tekshiruvi\n\n" +
        "🛍️ Ishonchingiz uchun rahmat!",
      [
        [{ text: "🎨 Premium eslatmalar", callback_data: "tpl:list" }],
        [{ text: "🔙 Ortga", callback_data: "menu" }],
      ],
    );
  }
  await show(
    chatId,
    fresh,
    "💎 <b>Premium tarif</b>\n\n" +
      "⭐ Premium afzalliklari\n" +
      "🌟 Boshqalardan o‘zgacha eslatma\n" +
      "👑 Premium foydalanuvchilar ro‘yxatiga qo‘shilish\n\n" +
      `💰 Narxi: ${PREMIUM_PRICE}`,
    [
      [{ text: "💰 Sotib olish", url: ADMIN_URL }],
      [{ text: "🔙 Ortga", callback_data: "menu" }],
    ],
  );
}

/* --------------------------- premium templates ---------------------------- */

const NOT_PREMIUM: InlineKeyboard = [
  [{ text: "💰 Sotib olish", url: ADMIN_URL }],
  [{ text: "🔙 Ortga", callback_data: "menu" }],
];

async function templatesScreen(chatId: number, fresh = false) {
  const info = await getPremiumInfo(chatId);
  if (!info.active) {
    return await show(
      chatId,
      fresh,
      `💎 Premium eslatmalar faqat Premium foydalanuvchilar uchun.\n\n💰 Premium narxi: ${PREMIUM_PRICE}`,
      NOT_PREMIUM,
    );
  }
  const selected = info.selected_template_id ?? 1;
  const birthday = await getBirthday(chatId);
  const birth = birthday
    ? {
        year: Number(birthday.birth_year),
        month: Number(birthday.birth_month),
        day: Number(birthday.birth_day),
      }
    : { year: tashkentToday().year - 20, month: 1, day: 1 };

  const rows: InlineKeyboard = [];
  for (let i = 0; i < PREMIUM_TEMPLATES.length; i += 3) {
    rows.push(
      PREMIUM_TEMPLATES.slice(i, i + 3).map((t) => ({
        text: t.id === selected ? `✅ ${t.label}` : t.label,
        callback_data: `tpl:s:${t.id}`,
      })),
    );
  }
  rows.push([{ text: "🔙 Ortga", callback_data: "menu" }]);

  const current = PREMIUM_TEMPLATES.find((t) => t.id === selected) ?? PREMIUM_TEMPLATES[0]!;
  const preview = renderReminderTemplate(current.text, birth);
  await show(
    chatId,
    fresh,
    `🎨 <b>Premium eslatmalar</b>\n\nHozirgi tanlov: <b>${current.label}</b>\n\n${preview}\n\n👇 Boshqa ko‘rinishni tanlang:`,
    rows,
  );
}



async function yearPicker(chatId: number, page = 0, fresh = false) {
  const current = new Date().getFullYear();
  const years: number[] = [];
  for (let y = current; y >= 1940; y--) years.push(y);
  const perPage = 12;
  const slice = years.slice(page * perPage, page * perPage + perPage);
  const rows: InlineKeyboard = [];
  for (let i = 0; i < slice.length; i += 3) {
    rows.push(slice.slice(i, i + 3).map((y) => ({ text: String(y), callback_data: `by:s:${y}` })));
  }
  const nav: InlineKeyboard[number] = [];
  if (page > 0) nav.push({ text: "◀️", callback_data: `by:p:${page - 1}` });
  if ((page + 1) * perPage < years.length) nav.push({ text: "▶️", callback_data: `by:p:${page + 1}` });
  if (nav.length) rows.push(nav);
  rows.push([{ text: "🔙 Ortga", callback_data: "menu" }]);

  const state = await getState(chatId);
  const header =
    state.data?.['mode'] === "edit" && state.data?.['currentText']
      ? `✏️ <b>Tug‘ilgan kunni tahrirlash</b>\n\n📅 Hozirgi sana: ${state.data['currentText']}\n\n🗓 Yilni tanlang:`
      : "🎂 <b>Tug‘ilgan kun qo‘shish</b>\n\n🗓 Yilni tanlang:";
  await show(chatId, fresh, header, rows);
}

async function monthPicker(chatId: number, year: number) {
  const rows: InlineKeyboard = [];
  for (let i = 0; i < 12; i += 3) {
    rows.push(
      MONTHS.slice(i, i + 3).map((name, idx) => ({ text: name, callback_data: `bm:${i + idx + 1}` })),
    );
  }
  rows.push([{ text: "🔙 Ortga", callback_data: "by:p:0" }]);
  await panel(chatId, `🎂 <b>Tanlangan yil: ${year}</b>\n\n📆 Oyni tanlang:`, rows);
}

async function dayPicker(chatId: number, year: number, month: number) {
  const total = daysInMonth(year, month);
  const rows: InlineKeyboard = [];
  for (let d = 1; d <= total; d += 7) {
    const row: InlineKeyboard[number] = [];
    for (let i = d; i < d + 7 && i <= total; i++) row.push({ text: String(i), callback_data: `bd:${i}` });
    rows.push(row);
  }
  rows.push([{ text: "🔙 Ortga", callback_data: `by:s:${year}` }]);
  await panel(
    chatId,
    `🎂 <b>${year} — ${MONTHS[month - 1]}</b>\n\n📅 Kunni tanlang (1–${total}):`,
    rows,
  );
}

/* ------------------------------ admin panel ------------------------------- */

const ADMIN_KEYBOARD: InlineKeyboard = [
  [
    { text: "💎 Tarif berish", callback_data: "a:grant" },
    { text: "🚫 Tarif uzish", callback_data: "a:revoke" },
  ],
  [
    { text: "👥 Tarif olganlar ro‘yxati", callback_data: "a:list" },
    { text: "📊 Statistika", callback_data: "a:stats" },
  ],
  [
    { text: "📢 Kanal ulash", callback_data: "a:addch" },
    { text: "🔌 Kanal uzish", callback_data: "a:delch" },
  ],
  [
    { text: "📋 Ulangan kanallar", callback_data: "a:chlist" },
    { text: "📤 Xabar yuborish", callback_data: "a:bcast" },
  ],
  [{ text: "🔙 Ortga", callback_data: "menu" }],
];

async function adminPanel(chatId: number) {
  await setState(chatId, { state: null, data: {} });
  await panel(chatId, "👨‍💻 <b>Admin panel</b>\n\nKerakli bo‘limni tanlang:", ADMIN_KEYBOARD);
}

const ADMIN_BACK: InlineKeyboard = [[{ text: "🔙 Ortga", callback_data: "a:panel" }]];

/* ------------------------- channel link resolving ------------------------- */

function parseChatInput(input: string) {
  const value = input.trim();
  if (value.startsWith("@")) return { kind: "username" as const, value };
  const match = value.match(/^https?:\/\/t\.me\/(.+)$/i);
  if (match) {
    const rest = match[1]!;
    if (rest.startsWith("+") || rest.startsWith("joinchat/")) return { kind: "invite" as const, value };
    return { kind: "username" as const, value: `@${rest.split("/")[0]}` };
  }
  if (/^[A-Za-z0-9_]{4,}$/.test(value)) return { kind: "username" as const, value: `@${value}` };
  return { kind: "unknown" as const, value };
}

async function resolveChat(input: string) {
  const parsed = parseChatInput(input);
  if (parsed.kind === "username") {
    const res = await tg<any>("getChat", { chat_id: parsed.value });
    if (!res.ok || !res.result) return { error: res.description ?? "Topilmadi" };
    return { chat: res.result };
  }
  if (parsed.kind === "invite") {
    // A private invite link is NOT a chat_id and must never be sent to the API.
    // We only use it as a label; the real chat_id comes from updates the bot
    // received inside the group/channel (my_chat_member, messages, posts).
    const chats = await listChats(false);
    const normalized = parsed.value.replace(/\/$/, "");
    const found = chats.find((c: any) => (c.invite_link ?? "").replace(/\/$/, "") === normalized);
    if (found) {
      const res = await tg<any>("getChat", { chat_id: Number(found.chat_id) });
      if (res.ok && res.result) return { chat: res.result, invite_link: parsed.value };
      return {
        chat: { id: Number(found.chat_id), type: found.chat_type, title: found.title },
        invite_link: parsed.value,
      };
    }
    // Private chats the bot already knows about (no public username).
    const candidates = chats.filter((c: any) => !c.username);
    if (candidates.length) return { candidates, invite_link: parsed.value };
    return {
      error:
        "Maxfiy guruh aniqlandi, lekin bot hali guruh ID sini olmagan.\n\nBotni guruhga admin qilib qo‘shing va guruhga bitta xabar yuboring (yoki kanalga post joylang). Shundan keyin havolani qayta yuboring.",
    };
  }
  return { error: "Noto‘g‘ri format" };
}

/** Records a chat the bot is present in, so its real chat_id becomes known. */
async function discoverChat(chat: any) {
  if (!chat || !["channel", "supergroup", "group"].includes(chat.type)) return;
  const full = await tg<any>("getChat", { chat_id: chat.id });
  const info = full.ok ? full.result : chat;
  const existing = await getChat(Number(chat.id));
  await saveChat({
    chat_id: Number(chat.id),
    chat_type: chat.type,
    title: info.title ?? chat.title ?? null,
    username: info.username ?? chat.username ?? null,
    invite_link: info.invite_link ?? existing?.invite_link ?? null,
    is_request_based: Boolean(info.join_by_request),
  });
  if (!existing) {
    // newly discovered chats stay inactive until the admin connects them
    const { db } = await import("./db.server");
    await db().from("mandatory_chats").update({ active: false }).eq("chat_id", Number(chat.id));
  }
}

/* ------------------------------- handlers -------------------------------- */

export async function handleUpdate(update: any) {
  try {
    if (update.message) return await onMessage(update.message);
    if (update.callback_query) return await onCallback(update.callback_query);
    if (update.channel_post) return await discoverChat(update.channel_post.chat);
    if (update.chat_join_request) {
      const req = update.chat_join_request;
      await upsertUser(req.from);
      await saveJoinRequest(Number(req.chat.id), Number(req.from.id));
      return;
    }
    if (update.my_chat_member) return await onMyChatMember(update.my_chat_member);
  } catch (error) {
    console.error("[bot] update handling failed", error);
  }
}

async function onMyChatMember(event: any) {
  const chat = event.chat;
  const status = event.new_chat_member?.status;
  if (!["member", "administrator", "creator"].includes(status)) return;
  await discoverChat(chat);
}

async function onMessage(message: any) {
  const chatId = Number(message.chat.id);
  if (message.chat.type !== "private") {
    // Group/channel message: this is how we learn a private chat's real id.
    return await discoverChat(message.chat);
  }
  const from = message.from;
  if (!from) return;
  upsertUser(from);
  const userId = Number(from.id);
  const text: string | undefined = message.text;

  if (text === "/start") {
    await setState(chatId, { state: null, data: {} });
    const { chats, ok } = await checkSubscription(userId);
    if (chats.length > 0 && !ok) {
      const keyboard = await subscribeKeyboard(chats);
      if (keyboard.length > 0) {
        const sent = await sendMessage(chatId, SUB_TEXT, keyboard);
        if (sent.ok && sent.result) await setState(chatId, { message_id: sent.result.message_id });
        return;
      }
      // No usable buttons could be built — never show a button-less gate.
      console.error("[start] mandatory chats exist but no buttons could be built; letting user through");
    }
    const sent = await tg<{ message_id: number }>("sendMessage", {
      chat_id: chatId,
      text: WELCOME,
      parse_mode: "HTML",
      reply_markup: quickKeyboard,
    });
    if (sent.ok && sent.result) await setState(chatId, { message_id: sent.result.message_id });
    return;
  }

  if (text === "/admin") {
    if (userId === ADMIN_ID) {
      const sent = await sendMessage(chatId, "👨‍💻 <b>Admin panel</b>\n\nKerakli bo‘limni tanlang:", ADMIN_KEYBOARD);
      if (sent.ok && sent.result) await setState(chatId, { state: null, data: {}, message_id: sent.result.message_id });
    } else {
      const sent = await sendMessage(chatId, "👨‍💻 Admin bilan bog‘lanish uchun quyidagi tugmani bosing.", [
        [{ text: "👨‍💻 Admin bilan bog‘lanish", url: ADMIN_URL }],
      ]);
      if (sent.ok && sent.result) await setState(chatId, { message_id: sent.result.message_id });
    }
    return;
  }

  // Quick actions (persistent keyboard) — always open a NEW message,
  // the Welcome/Main message stays untouched.
  if (text === QUICK.add) return await startAddBirthday(chatId, true);
  if (text === QUICK.edit) return await startEditBirthday(chatId, true);
  if (text === QUICK.reminder) return await reminderEntry(chatId, true);
  if (text === QUICK.templates) return await templatesScreen(chatId, true);
  if (text === QUICK.premium) return await premiumScreen(chatId, true);


  const state = await getState(chatId);

  if (state.state === "reminder" && text) {
    if (!(await isPremium(userId))) return await reminderEntry(chatId);
    await saveReminder(userId, text);
    await setState(chatId, { state: null });
    // Keep the chat clean: remove the raw text the user just typed.
    await tg("deleteMessage", { chat_id: chatId, message_id: message.message_id });
    return await panel(
      chatId,
      `✅ <b>Saqlandi!</b>\n\n📝 Yangi shaxsiy eslatmangiz:\n\n${text}`,
      BACK,
    );
  }

  if (userId !== ADMIN_ID) return;

  if (state.state === "grant" && text) {
    const target = Number(text.trim());
    if (!Number.isFinite(target) || target <= 0) {
      return await panel(chatId, "⚠️ Noto‘g‘ri ID. Iltimos, raqamli Telegram ID yuboring.", ADMIN_BACK);
    }
    try {
      await grantPremium(target, ADMIN_ID);
    } catch (e) {
      console.error("[admin] grant failed", e);
      return await panel(chatId, "⚠️ Tarif berishda xatolik. Qayta urinib ko‘ring.", ADMIN_BACK);
    }
    await setState(chatId, { state: null });
    await sendMessage(
      target,
      "🎉 <b>Tabriklaymiz!</b>\n\n💎 Sizga Premium obunasi berildi!\n⭐ Endi Premium imkoniyatlaridan foydalanishingiz mumkin.\n\n🛍️ Xaridingiz uchun rahmat!",
    );
    return await panel(
      chatId,
      "✅ <b>Muvaffaqiyatli!</b>\n\n💎 Premium hadiyasi muvaffaqiyatli yuborildi!",
      ADMIN_BACK,
    );
  }

  if (state.state === "revoke" && text) {
    const target = Number(text.trim());
    if (!Number.isFinite(target) || target <= 0) {
      return await panel(chatId, "⚠️ Noto‘g‘ri ID. Iltimos, raqamli Telegram ID yuboring.", ADMIN_BACK);
    }
    await setState(chatId, { state: null });
    if (!(await isPremium(target))) {
      return await panel(chatId, "⚠️ Ushbu foydalanuvchida Premium mavjud emas.", ADMIN_BACK);
    }
    await revokePremium(target, ADMIN_ID);
    await sendMessage(
      target,
      "⚠️ <b>Premium obunangiz bekor qilindi.</b>\n\nAgar sababini bilmoqchi bo‘lsangiz, admin bilan bog‘lanishingiz mumkin.",
      [[{ text: "💬 Sabab", url: ADMIN_URL }]],
    );
    return await panel(
      chatId,
      "✅ <b>Muvaffaqiyatli!</b>\n\n🚫 Foydalanuvchining Premium obunasi bekor qilindi.",
      ADMIN_BACK,
    );
  }

  if (state.state === "addch" && text) {
    const resolved: any = await resolveChat(text);
    if (resolved.error) {
      return await panel(chatId, `⚠️ <b>Ulanmadi.</b>\n\n${resolved.error}`, ADMIN_BACK);
    }
    if (resolved.candidates) {
      await setState(chatId, { state: "addch", data: { invite_link: resolved.invite_link } });
      const keyboard: InlineKeyboard = resolved.candidates.map((c: any) => [
        { text: `📢 ${c.title ?? c.chat_id}`, callback_data: `a:chpick:${c.chat_id}` },
      ]);
      keyboard.push([{ text: "🔙 Ortga", callback_data: "a:panel" }]);
      return await panel(
        chatId,
        "🔒 <b>Maxfiy havola qabul qilindi.</b>\n\nQuyidagi maxfiy guruh/kanallardan qaysi biri ekanini tanlang:",
        keyboard,
      );
    }
    const chat = resolved.chat;
    const member = await tg<any>("getChatMember", { chat_id: chat.id, user_id: await botId() });
    if (!member.ok || !["administrator", "creator"].includes(member.result?.status)) {
      return await panel(
        chatId,
        "⚠️ Bot ushbu kanal/guruhda administrator emas. Avval botni admin qiling va qayta urinib ko‘ring.",
        ADMIN_BACK,
      );
    }
    await saveChat({
      chat_id: Number(chat.id),
      chat_type: chat.type,
      title: chat.title ?? null,
      username: chat.username ?? null,
      invite_link:
        resolved.invite_link ?? chat.invite_link ?? (chat.username ? `https://t.me/${chat.username}` : null),
      is_request_based: Boolean(chat.join_by_request),
    });
    await setState(chatId, { state: null });
    return await panel(
      chatId,
      "🎉 <b>Muvaffaqiyatli ulandi!</b>\n\n📢 Kanal/guruh majburiy obunaga qo‘shildi.\n✅ Endi foydalanuvchilar uchun obuna tekshiriladi.",
      ADMIN_BACK,
    );
  }

  if (state.state === "bcast") {
    await setState(chatId, {
      state: "bcast_confirm",
      data: { ...state.data, from_chat_id: chatId, message_id_src: message.message_id },
    });
    return await panel(chatId, "📢 <b>Xabar yuborilsinmi?</b>\n\n⬆️ Yuqoridagi xabar barcha foydalanuvchilarga yuboriladi.", [
      [{ text: "✅ Tasdiqlash", callback_data: "a:bcgo" }],
      [{ text: "🔙 Ortga", callback_data: "a:panel" }],
    ]);
  }
}

let cachedBotId: number | null = null;
async function botId() {
  if (cachedBotId) return cachedBotId;
  const me = await tg<any>("getMe");
  cachedBotId = me.ok ? Number(me.result.id) : 0;
  return cachedBotId;
}

/* ------------------------------ user flows -------------------------------- */

async function startAddBirthday(chatId: number, fresh = false) {
  const existing = await getBirthday(chatId);
  if (existing) {
    return await show(chatId, fresh, "🎂 Siz allaqachon tug‘ilgan kun qo‘shgansiz.", BACK);
  }
  await setState(chatId, { state: null, data: { mode: "add" } });
  await yearPicker(chatId, 0, fresh);
}

async function startEditBirthday(chatId: number, fresh = false) {
  const existing = await getBirthday(chatId);
  if (!existing) {
    return await show(
      chatId,
      fresh,
      "⚠️ Siz hali tug‘ilgan kuningizni qo‘shmagansiz.\n\nAvval tug‘ilgan kuningizni qo‘shing.",
      BACK,
    );
  }
  const currentText = `${existing.birth_year}-${String(existing.birth_month).padStart(2, "0")}-${String(
    existing.birth_day,
  ).padStart(2, "0")}`;
  await setState(chatId, { state: null, data: { mode: "edit", currentText } });
  await yearPicker(chatId, 0, fresh);
}

async function reminderEntry(chatId: number, fresh = false) {
  if (await isPremium(chatId)) {
    await setState(chatId, { state: "reminder" });
    return await show(chatId, fresh, "🔔 Marhamat, yangi xabarni yozing.", BACK);
  }
  await setState(chatId, { state: null });
  return await show(
    chatId,
    fresh,
    `💎 Ushbu funksiya faqat Premium foydalanuvchilar uchun mavjud.\n\n💰 Premium narxi: ${PREMIUM_PRICE}`,
    [
      [{ text: "💰 Sotib olish", url: ADMIN_URL }],
      [{ text: "🔙 Ortga", callback_data: "menu" }],
    ],
  );
}

/* -------------------------------- callbacks ------------------------------- */

async function onCallback(query: any) {
  const data: string = query.data ?? "";
  const chatId = Number(query.message?.chat?.id);
  const userId = Number(query.from.id);
  if (!chatId) return await answerCallback(query.id);
  // Acknowledge the button press FIRST so Telegram stops showing the spinner,
  // then do bookkeeping while the user already sees the reaction.
  await answerCallback(query.id);
  upsertUser(query.from);
  void setState(chatId, { message_id: Number(query.message.message_id) });

  const isAdmin = userId === ADMIN_ID;

  if (data === "sub:check") {
    const { chats, ok } = await checkSubscription(userId);
    if (ok) {
      await tg("deleteMessage", { chat_id: chatId, message_id: Number(query.message.message_id) });
      const sent = await tg<{ message_id: number }>("sendMessage", {
        chat_id: chatId,
        text: WELCOME,
        parse_mode: "HTML",
        reply_markup: quickKeyboard,
      });
      if (sent.ok && sent.result) await setState(chatId, { message_id: sent.result.message_id });
      return;
    }
    return await editMessage(
      chatId,
      Number(query.message.message_id),
      "⚠️ Siz hali barcha kanallarimizga obuna bo‘lmagansiz.\n\nIltimos, yuqoridagi kanallarga obuna bo‘ling va qaytadan ✅ Obuna bo‘ldim tugmasini bosing.",
      await subscribeKeyboard(chats),
    );
  }

  if (data === "menu") {
    await setState(chatId, { state: null, data: {} });
    return await showMain(chatId);
  }

  /* --------------------------- life check ------------------------------- */

  if (data.startsWith("life:")) {
    const answer = data.split(":")[1] === "yes" ? "yes" : "no";
    const dateKey = tashkentDateString();
    const accepted = await answerLifeCheck(userId, dateKey, answer);
    const text =
      answer === "yes"
        ? "🤍 <b>Rahmat!</b>\n\nTiriklikni tasdiqladingiz. Sog‘lom va baxtli bo‘ling!"
        : "😔 Javobingiz qabul qilindi.\n\nAgar yordam kerak bo‘lsa, admin bilan bog‘laning.";
    return await editMessage(
      chatId,
      Number(query.message.message_id),
      accepted ? text : "ℹ️ Siz bugungi tekshiruvga allaqachon javob bergansiz.",
      answer === "no" ? [[{ text: "💬 Admin", url: ADMIN_URL }]] : undefined,
    );
  }

  /* ------------------------ premium templates ---------------------------- */

  if (data === "tpl:list") return await templatesScreen(chatId);

  if (data.startsWith("tpl:s:")) {
    const id = Number(data.split(":")[2]);
    const info = await getPremiumInfo(chatId);
    if (!info.active) return await templatesScreen(chatId);
    if (PREMIUM_TEMPLATES.some((t) => t.id === id)) await setSelectedTemplate(chatId, id);
    return await templatesScreen(chatId);
  }


  if (data.startsWith("by:p:")) return await yearPicker(chatId, Number(data.split(":")[2]));

  if (data.startsWith("by:s:")) {
    const year = Number(data.split(":")[2]);
    const state = await getState(chatId);
    await setState(chatId, { data: { ...state.data, year } });
    return await monthPicker(chatId, year);
  }

  if (data.startsWith("bm:")) {
    const month = Number(data.split(":")[1]);
    const state = await getState(chatId);
    const year = Number(state.data?.['year']) || new Date().getFullYear();
    await setState(chatId, { data: { ...state.data, month } });
    return await dayPicker(chatId, year, month);
  }

  if (data.startsWith("bd:")) {
    const day = Number(data.split(":")[1]);
    const state = await getState(chatId);
    const year = Number(state.data?.['year']);
    const month = Number(state.data?.['month']);
    if (!year || !month) return await showMain(chatId);
    if (day < 1 || day > daysInMonth(year, month)) {
      return await dayPicker(chatId, year, month);
    }
    await saveBirthday(userId, year, month, day);
    await setState(chatId, { state: null, data: {} });
    return await panel(
      chatId,
      `🎉 <b>Saqlandi!</b>\n\n🎂 Tug‘ilgan kuningiz: <b>${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}</b>`,
      BACK,
    );
  }

  /* ------------------------------ admin ---------------------------------- */

  if (data.startsWith("a:")) {
    if (!isAdmin) return;

    if (data === "a:panel") return await adminPanel(chatId);

    if (data === "a:grant") {
      await setState(chatId, { state: "grant" });
      return await panel(chatId, "💎 <b>Tarif berish</b>\n\n👤 Tarif oluvchi ID sini yuboring", ADMIN_BACK);
    }

    if (data === "a:revoke") {
      await setState(chatId, { state: "revoke" });
      return await panel(
        chatId,
        "🚫 <b>Obunani bekor qilish</b>\n\n👤 Obunani bekor qilish uchun foydalanuvchi ID sini yuboring",
        ADMIN_BACK,
      );
    }

    if (data === "a:list") {
      const rows = await listPremium();
      const keyboard: InlineKeyboard = [];
      for (let i = 0; i < rows.length; i += 3) {
        keyboard.push(
          rows.slice(i, i + 3).map((r: any) => ({ text: String(r.tg_id), callback_data: `a:u:${r.tg_id}` })),
        );
      }
      keyboard.push([{ text: "🔙 Ortga", callback_data: "a:panel" }]);
      return await panel(
        chatId,
        rows.length
          ? "👥 <b>Hozirgi vaqtda Premium faol foydalanuvchilar:</b>"
          : "👥 Hozirda faol Premium foydalanuvchilar yo‘q.",
        keyboard,
      );
    }

    if (data.startsWith("a:u:")) {
      const target = Number(data.split(":")[2]);
      const row = await getPremiumRow(target);
      const { date, time } = fmtDate(row?.granted_at);
      return await panel(
        chatId,
        `👤 <b>Foydalanuvchi ma’lumotlari</b>\n\n🆔 ID: <code>${target}</code>\n💎 Tarif: Premium\n📅 Berilgan sana: ${date}\n🕐 Berilgan vaqt: ${time}`,
        [[{ text: "🔙 Ortga", callback_data: "a:list" }]],
      );
    }

    if (data === "a:stats") {
      const [users, premium] = await Promise.all([countUsers(), countPremium()]);
      return await panel(
        chatId,
        `📊 <b>Statistika</b>\n\n👥 Botdan foydalanayotganlar: <b>${users}</b>\n💎 Premium foydalanuvchilar: <b>${premium}</b>`,
        ADMIN_BACK,
      );
    }

    if (data === "a:addch") {
      await setState(chatId, { state: "addch" });
      return await panel(
        chatId,
        "📢 <b>Majburiy obunaga ulash</b>\n\nMarhamat, ulanuvchi kanal yoki guruh usernamesi yoki maxfiy linkni yuboring.\n\nMasalan:\n<code>@kanal_username</code>\nyoki\n<code>https://t.me/+xPo3Ga24DIhjN2Uy</code>",
        ADMIN_BACK,
      );
    }

    if (data.startsWith("a:chpick:")) {
      const target = Number(data.split(":")[2]);
      const st = await getState(chatId);
      const invite = (st.data?.["invite_link"] as string | undefined) ?? null;
      const res = await tg<any>("getChat", { chat_id: target });
      if (!res.ok || !res.result) {
        return await panel(chatId, "⚠️ Guruh ma’lumotini olib bo‘lmadi. Bot hali guruhda emasmi?", ADMIN_BACK);
      }
      const info = res.result;
      const member = await tg<any>("getChatMember", { chat_id: target, user_id: await botId() });
      if (!member.ok || !["administrator", "creator"].includes(member.result?.status)) {
        return await panel(
          chatId,
          "⚠️ Bot ushbu guruhda administrator emas. Avval botni admin qiling va qayta urinib ko‘ring.",
          ADMIN_BACK,
        );
      }
      await saveChat({
        chat_id: target,
        chat_type: info.type,
        title: info.title ?? null,
        username: info.username ?? null,
        invite_link: invite ?? info.invite_link ?? null,
        is_request_based: Boolean(info.join_by_request),
      });
      await setState(chatId, { state: null, data: {} });
      return await panel(
        chatId,
        "🎉 <b>Muvaffaqiyatli ulandi!</b>\n\n🔒 Maxfiy guruh majburiy obunaga qo‘shildi.\n✅ Obuna tekshiruvi guruh ID orqali amalga oshiriladi.",
        ADMIN_BACK,
      );
    }

    if (data === "a:delch") {
      const chats = await listChats();
      const keyboard: InlineKeyboard = chats.map((c: any) => [
        { text: `🔌 ${c.title ?? c.username ?? c.chat_id}`, callback_data: `a:chdel:${c.chat_id}` },
      ]);
      keyboard.push([{ text: "🔙 Ortga", callback_data: "a:panel" }]);
      return await panel(
        chatId,
        chats.length ? "🔌 <b>Kanal uzish</b>\n\nUziladigan kanal/guruhni tanlang:" : "⚠️ Ulangan kanal/guruh yo‘q.",
        keyboard,
      );
    }

    if (data === "a:chlist") {
      const chats = await listChats();
      const keyboard: InlineKeyboard = chats.map((c: any) => [
        { text: `📢 ${c.title ?? c.username ?? c.chat_id}`, callback_data: `a:ch:${c.chat_id}` },
      ]);
      keyboard.push([{ text: "🔙 Ortga", callback_data: "a:panel" }]);
      return await panel(
        chatId,
        chats.length ? "📋 <b>Ulangan kanallar</b>\n\nBatafsil ma’lumot uchun tanlang:" : "⚠️ Ulangan kanal/guruh yo‘q.",
        keyboard,
      );
    }

    if (data.startsWith("a:ch:")) {
      const target = Number(data.split(":")[2]);
      const chat = await getChat(target);
      if (!chat) return await panel(chatId, "⚠️ Kanal topilmadi.", ADMIN_BACK);
      const { date, time } = fmtDate(chat.connected_at);
      return await panel(
        chatId,
        `📢 <b>Kanal/Guruh ma’lumotlari</b>\n\n📛 Nomi: ${chat.title ?? "-"}\n🆔 ID: <code>${chat.chat_id}</code>\n🔗 Username/Link: ${
          chat.username ? "@" + chat.username : (chat.invite_link ?? "-")
        }\n📅 Ulangan sana: ${date}\n🕐 Ulangan vaqt: ${time}`,
        [
          [{ text: "🔌 Kanalni uzish", callback_data: `a:chdel:${chat.chat_id}` }],
          [{ text: "🔙 Ortga", callback_data: "a:chlist" }],
        ],
      );
    }

    if (data.startsWith("a:chdel:")) {
      const target = Number(data.split(":")[2]);
      await removeChat(target);
      return await panel(
        chatId,
        "✅ <b>Muvaffaqiyatli!</b>\n\n🔌 Kanal/guruh majburiy obunadan olib tashlandi.",
        ADMIN_BACK,
      );
    }

    if (data === "a:bcast") {
      await setState(chatId, { state: "bcast", data: {} });
      return await panel(chatId, "📤 Marhamat, kerakli xabarni yuboring.", ADMIN_BACK);
    }

    if (data === "a:bcgo") {
      const state = await getState(chatId);
      const srcChat = Number(state.data?.['from_chat_id']);
      const srcMsg = Number(state.data?.['message_id_src']);
      await setState(chatId, { state: null, data: {} });
      if (!srcChat || !srcMsg) return await adminPanel(chatId);

      await panel(chatId, "🚀 <b>Xabar yuborish jarayoni boshlandi...</b>\n\n⏳ Iltimos, biroz kuting...");
      const logId = await startBroadcast(ADMIN_ID, { from_chat_id: srcChat, message_id: srcMsg });
      const ids = await allUserIds();
      let sent = 0;
      let failed = 0;
      for (const id of ids) {
        const res = await tg("copyMessage", { chat_id: id, from_chat_id: srcChat, message_id: srcMsg });
        if (res.ok) sent++;
        else failed++;
        await new Promise((r) => setTimeout(r, 35));
      }
      await finishBroadcast(logId, sent, failed);
      return await panel(
        chatId,
        `🎉 <b>Muvaffaqiyatli yakunlandi!</b>\n\n📤 Xabar yuborildi.\n✅ Yuborildi: ${sent} ta\n❌ Rad etildi: ${failed} ta\n\n🏁 Jarayon muvaffaqiyatli yakunlandi!`,
        ADMIN_BACK,
      );
    }
  }
}
