/**
 * Centralised birthday reminder placeholder rendering.
 * Server-only. All dates are handled in Asia/Tashkent (UTC+5).
 */

export const TASHKENT_OFFSET_MS = 5 * 60 * 60 * 1000;

/** Current Y/M/D in Tashkent. */
export function tashkentToday(now: Date = new Date()) {
  const d = new Date(now.getTime() + TASHKENT_OFFSET_MS);
  return { year: d.getUTCFullYear(), month: d.getUTCMonth() + 1, day: d.getUTCDate() };
}

export function tashkentDateString(now: Date = new Date()) {
  const { year, month, day } = tashkentToday(now);
  return `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
}

function daysInMonth(year: number, month: number) {
  return new Date(Date.UTC(year, month, 0)).getUTCDate();
}

/** Calendar difference (years, months, days) between two Y/M/D dates. */
function diffYMD(
  from: { year: number; month: number; day: number },
  to: { year: number; month: number; day: number },
) {
  let years = to.year - from.year;
  let months = to.month - from.month;
  let days = to.day - from.day;
  if (days < 0) {
    months -= 1;
    const prevMonth = to.month === 1 ? 12 : to.month - 1;
    const prevYear = to.month === 1 ? to.year - 1 : to.year;
    days += daysInMonth(prevYear, prevMonth);
  }
  if (months < 0) {
    years -= 1;
    months += 12;
  }
  return { years, months, days };
}

export type ReminderValues = {
  elapsed_years: number;
  elapsed_months: number;
  elapsed_days: number;
  remaining_months: number;
  remaining_days: number;
};

/** Elapsed time since birth and time left until the next birthday. */
export function computeReminderValues(
  birth: { year: number; month: number; day: number },
  today = tashkentToday(),
): ReminderValues {
  const elapsed = diffYMD(birth, today);

  // Next birthday (clamped to the month length, e.g. Feb 29 -> Feb 28).
  let nextYear = today.year;
  const clampDay = (y: number) => Math.min(birth.day, daysInMonth(y, birth.month));
  const thisYearDay = clampDay(today.year);
  const passed =
    birth.month < today.month || (birth.month === today.month && thisYearDay < today.day);
  if (passed) nextYear = today.year + 1;
  const next = { year: nextYear, month: birth.month, day: clampDay(nextYear) };

  const remaining = diffYMD(today, next);
  return {
    elapsed_years: elapsed.years,
    elapsed_months: elapsed.months,
    elapsed_days: elapsed.days,
    remaining_months: remaining.years * 12 + remaining.months,
    remaining_days: remaining.days,
  };
}

export const FREE_TEMPLATE =
  "🎂 Tavallud topganingizga {{elapsed_years}} yil, {{elapsed_months}} oy, {{elapsed_days}} kun bo‘ldi.\n" +
  "🎉 Keyingi tavallud kuningizga {{remaining_months}} oy, {{remaining_days}} kun qoldi.";

export const PREMIUM_TEMPLATES: { id: number; label: string; text: string }[] = [
  {
    id: 1,
    label: "🌿 1",
    text:
      "🌿 Hayotingizning {{elapsed_years}} yil, {{elapsed_months}} oy, {{elapsed_days}} kuni ortda qoldi.\n" +
      "🎉 Tug‘ilgan kuningizgacha {{remaining_months}} oy, {{remaining_days}} kun qoldi.",
  },
  {
    id: 2,
    label: "⏳ 2",
    text:
      "⏳ {{elapsed_years}} yil {{elapsed_months}} oy {{elapsed_days}} kun — ortda qolgan vaqt.\n" +
      "🎂 {{remaining_months}} oy {{remaining_days}} kun — keyingi tug‘ilgan kungacha.",
  },
  {
    id: 3,
    label: "🌙 3",
    text:
      "🌙 Vaqt sezdirmay o‘tmoqda...\n" +
      "{{elapsed_years}} yil • {{elapsed_months}} oy • {{elapsed_days}} kun ortda qoldi.\n" +
      "✨ Yangi yoshingizgacha {{remaining_months}} oy • {{remaining_days}} kun qoldi.",
  },
  {
    id: 4,
    label: "📖 4",
    text:
      "📖 Hayotingiz — {{elapsed_years}} yil, {{elapsed_months}} oy, {{elapsed_days}} kunlik hikoya.\n" +
      "📚 Bu hikoyaning keyingi sahifasigacha {{remaining_months}} oy, {{remaining_days}} kun qoldi.",
  },
  {
    id: 5,
    label: "🚀 5",
    text:
      "🚀 {{elapsed_years}} yil, {{elapsed_months}} oy, {{elapsed_days}} kun — hayotingizdagi katta yo‘lning bir qismi.\n" +
      "🏆 Keyingi bosqichga chiqishingizga {{remaining_months}} oy, {{remaining_days}} kun qoldi!",
  },
  {
    id: 6,
    label: "🏁 6",
    text:
      "🎯 Niyatdagi 200 yildan {{elapsed_years}} yil, {{elapsed_months}} oy, {{elapsed_days}} kuniga erishildi.\n" +
      "🚀 Keyingi marragacha {{remaining_months}} oy, {{remaining_days}} kun qoldi.",
  },
];

export function getTemplateById(id: number | null | undefined) {
  return PREMIUM_TEMPLATES.find((t) => t.id === Number(id));
}

/**
 * Replace every {{placeholder}} with the real value.
 * Guarantees no raw placeholder can reach Telegram.
 */
export function renderReminderTemplate(
  template: string,
  birth: { year: number; month: number; day: number },
  today = tashkentToday(),
) {
  const values = computeReminderValues(birth, today) as unknown as Record<string, number>;
  return template.replace(/\{\{\s*(\w+)\s*\}\}/g, (_match, key: string) =>
    String(values[key] ?? 0),
  );
}
