/**
 * Independent scheduled jobs. Server-only.
 *
 *  07:00 Asia/Tashkent — daily elapsed/remaining reminder (free + premium)
 *  08:00 Asia/Tashkent — premium life check
 *  00:00 Asia/Tashkent — birthday greeting
 *
 * Each job is fully independent, per-user isolated, and duplicate-safe through
 * the notification_log table.
 */
import { sendMessage, tg, type InlineKeyboard } from "./api.server";
import {
  activePremiumIds,
  allBirthdaysWithPremium,
  claimNotification,
  createLifeCheck,
  getReminder,
  markNotificationSent,
  releaseNotification,
} from "./db.server";
import {
  FREE_TEMPLATE,
  PREMIUM_TEMPLATES,
  getTemplateById,
  renderReminderTemplate,
  tashkentDateString,
  tashkentToday,
} from "./templates.server";

const CONCURRENCY = 8;

async function runPool<T>(items: T[], worker: (item: T) => Promise<boolean>) {
  let sent = 0;
  let failed = 0;
  let index = 0;
  const runners = Array.from({ length: Math.min(CONCURRENCY, items.length) }, async () => {
    while (index < items.length) {
      const item = items[index++]!;
      try {
        if (await worker(item)) sent++;
        else failed++;
      } catch (error) {
        failed++;
        console.error("[scheduler] item failed", error);
      }
    }
  });
  await Promise.all(runners);
  return { sent, failed };
}

/* ----------------------- 07:00 daily elapsed/remaining -------------------- */

export async function sendDailyReminders(force = false) {
  const today = tashkentToday();
  const dateKey = tashkentDateString();
  const users = await allBirthdaysWithPremium();

  const { sent, failed } = await runPool(users, async (user) => {
    if (!force && !(await claimNotification(user.tg_id, "daily", dateKey))) return true; // already sent

    const template = user.premium
      ? (getTemplateById(user.selected_template_id)?.text ?? PREMIUM_TEMPLATES[0]!.text)
      : FREE_TEMPLATE;

    const text = renderReminderTemplate(
      template,
      { year: user.birth_year, month: user.birth_month, day: user.birth_day },
      today,
    );

    const res = await sendMessage(user.tg_id, text);
    if (res.ok) await markNotificationSent(user.tg_id, "daily", dateKey);
    else if (!force) await releaseNotification(user.tg_id, "daily", dateKey);
    return res.ok;
  });

  return { job: "daily", date: dateKey, total: users.length, sent, failed };
}

/* --------------------------- 08:00 premium life check --------------------- */

const LIFE_KEYBOARD: InlineKeyboard = [
  [
    { text: "Tasdiqlash ✅", callback_data: "life:yes" },
    { text: "Rad etish ❌", callback_data: "life:no" },
  ],
];

export async function sendLifeChecks() {
  const dateKey = tashkentDateString();
  const ids = await activePremiumIds();

  const { sent, failed } = await runPool(ids, async (tgId) => {
    if (!(await claimNotification(tgId, "life", dateKey))) return true;
    const res = await sendMessage(tgId, "Iltimos tirik ekaningizni tasdiqlang", LIFE_KEYBOARD);
    if (!res.ok) {
      await releaseNotification(tgId, "life", dateKey);
      return false;
    }
    await markNotificationSent(tgId, "life", dateKey);
    await createLifeCheck(tgId, dateKey, res.result?.message_id ?? null);
    return true;
  });

  return { job: "life", date: dateKey, total: ids.length, sent, failed };
}

/* --------------------------- 00:00 birthday greeting ---------------------- */

const GREETING =
  "🎂✨ <b>Yangi yoshingiz muborak!</b>\n\n" +
  "Bugun — sizning kuningiz. 🤍\n" +
  "Yangi yoshingiz yangi imkoniyatlar, unutilmas lahzalar va chiroyli g‘alabalar olib kelsin. ✨\n\n" +
  "💎 Eng yaxshi kunlaringiz hali oldinda!\n\n" +
  "🚀 Siz bilan — Domians jamoasi";

export async function sendBirthdayGreetings() {
  const today = tashkentToday();
  const dateKey = tashkentDateString();
  const users = (await allBirthdaysWithPremium()).filter(
    (u) => u.birth_month === today.month && u.birth_day === today.day,
  );

  const { sent, failed } = await runPool(users, async (user) => {
    if (!(await claimNotification(user.tg_id, "birthday", dateKey))) return true;
    const custom = user.premium ? await getReminder(user.tg_id) : null;
    const text = custom ? `${GREETING}\n\n👑 ${custom}` : GREETING;
    const res = await sendMessage(user.tg_id, text);
    if (res.ok) await markNotificationSent(user.tg_id, "birthday", dateKey);
    else await releaseNotification(user.tg_id, "birthday", dateKey);
    return res.ok;
  });

  return { job: "birthday", date: dateKey, total: users.length, sent, failed };
}

export { tg };
