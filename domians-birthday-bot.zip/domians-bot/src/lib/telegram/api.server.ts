/**
 * Telegram Bot API access through the Lovable connector gateway.
 * Server-only: never import from client code.
 */

const GATEWAY_URL = "https://connector-gateway.lovable.dev/telegram";

export type TgResult<T = any> = { ok: boolean; result?: T; description?: string; error_code?: number };

export async function tg<T = any>(method: string, payload: Record<string, unknown> = {}): Promise<TgResult<T>> {
  const lovableKey = process.env["LOVABLE_API_KEY"];
  const telegramKey = process.env["TELEGRAM_API_KEY"];
  if (!lovableKey || !telegramKey) {
    return { ok: false, description: "Telegram credentials are not configured" };
  }

  try {
    const response = await fetch(`${GATEWAY_URL}/${method}`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${lovableKey}`,
        "X-Connection-Api-Key": telegramKey,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });

    const text = await response.text();
    let json: TgResult<T>;
    try {
      json = JSON.parse(text) as TgResult<T>;
    } catch {
      json = { ok: false, description: `Non-JSON response [${response.status}]: ${text.slice(0, 300)}` };
    }
    if (!response.ok && json.ok !== false) {
      json = { ok: false, description: `Telegram request failed [${response.status}]: ${text.slice(0, 300)}` };
    }
    if (!json.ok) {
      console.error(`[telegram] ${method} failed:`, json.description);
    }
    return json;
  } catch (error) {
    console.error(`[telegram] ${method} threw:`, error);
    return { ok: false, description: String(error) };
  }
}

export type InlineButton = { text: string; callback_data?: string; url?: string };
export type InlineKeyboard = InlineButton[][];

export function inline(keyboard: InlineKeyboard) {
  return { inline_keyboard: keyboard };
}

export async function sendMessage(
  chatId: number,
  text: string,
  keyboard?: InlineKeyboard,
  extra: Record<string, unknown> = {},
) {
  return tg<{ message_id: number }>("sendMessage", {
    chat_id: chatId,
    text,
    parse_mode: "HTML",
    disable_web_page_preview: true,
    ...(keyboard ? { reply_markup: inline(keyboard) } : {}),
    ...extra,
  });
}

export async function editMessage(
  chatId: number,
  messageId: number,
  text: string,
  keyboard?: InlineKeyboard,
) {
  return tg<{ message_id: number }>("editMessageText", {
    chat_id: chatId,
    message_id: messageId,
    text,
    parse_mode: "HTML",
    disable_web_page_preview: true,
    reply_markup: keyboard ? inline(keyboard) : { inline_keyboard: [] },
  });
}

export async function answerCallback(callbackQueryId: string, text?: string, alert = false) {
  return tg("answerCallbackQuery", {
    callback_query_id: callbackQueryId,
    ...(text ? { text, show_alert: alert } : {}),
  });
}
