/**
 * Database access for the Telegram bot. Server-only (service role).
 */
import { createClient, type SupabaseClient } from "@supabase/supabase-js";

let client: SupabaseClient | null = null;

export function db(): SupabaseClient {
  if (!client) {
    client = createClient(process.env["SUPABASE_URL"]!, process.env["SUPABASE_SERVICE_ROLE_KEY"]!, {
      auth: { persistSession: false, autoRefreshToken: false },
    });
  }
  return client;
}

export type TgUser = {
  id: number;
  username?: string;
  first_name?: string;
  last_name?: string;
};

/** Run a write without blocking the reply to Telegram. */
export function background(promise: PromiseLike<any>) {
  Promise.resolve(promise).catch((e) => console.error("[bot] background write failed", e));
}

const userSeen = new Map<number, number>();
const USER_TTL_MS = 60_000;

export async function upsertUser(user: TgUser) {
  const last = userSeen.get(user.id);
  if (last && Date.now() - last < USER_TTL_MS) return;
  userSeen.set(user.id, Date.now());
  background(
    db()
      .from("bot_users")
      .upsert(
        {
          tg_id: user.id,
          username: user.username ?? null,
          first_name: user.first_name ?? null,
          last_name: user.last_name ?? null,
          updated_at: new Date().toISOString(),
        },
        { onConflict: "tg_id" },
      ),
  );
}


/* ------------------------------- state ---------------------------------- */

export type BotState = {
  tg_id: number;
  state: string | null;
  data: Record<string, any>;
  message_id: number | null;
};

/**
 * Short-lived per-user state cache. Keyed by tg_id, so one user's state can
 * never leak into another's. Keeps a single update from re-reading the row.
 */
const stateCache = new Map<number, { at: number; value: BotState }>();
const STATE_TTL_MS = 3000;

export async function getState(tgId: number): Promise<BotState> {
  const cached = stateCache.get(tgId);
  if (cached && Date.now() - cached.at < STATE_TTL_MS) return cached.value;
  const { data } = await db().from("bot_states").select("*").eq("tg_id", tgId).maybeSingle();
  const value: BotState = {
    tg_id: tgId,
    state: data?.state ?? null,
    data: (data?.data as Record<string, any>) ?? {},
    message_id: data?.message_id ?? null,
  };
  stateCache.set(tgId, { at: Date.now(), value });
  return value;
}

export async function setState(
  tgId: number,
  patch: { state?: string | null; data?: Record<string, any>; message_id?: number | null },
) {
  const current = await getState(tgId);
  const next: BotState = {
    tg_id: tgId,
    state: patch.state !== undefined ? patch.state : current.state,
    data: patch.data !== undefined ? patch.data : current.data,
    message_id: patch.message_id !== undefined ? patch.message_id : current.message_id,
  };
  stateCache.set(tgId, { at: Date.now(), value: next });
  // Awaited: on the edge runtime un-awaited writes can be dropped after the
  // response, which lost multi-step states (e.g. admin "grant" waiting for an ID).
  const { error } = await db()
    .from("bot_states")
    .upsert(
      {
        tg_id: tgId,
        state: next.state,
        data: next.data,
        message_id: next.message_id,
        updated_at: new Date().toISOString(),
      },
      { onConflict: "tg_id" },
    );
  if (error) console.error("[bot] setState failed", error);

}


/* ------------------------------ birthdays -------------------------------- */

export async function getBirthday(tgId: number) {
  const { data } = await db().from("birthdays").select("*").eq("tg_id", tgId).maybeSingle();
  return data;
}

export async function saveBirthday(tgId: number, year: number, month: number, day: number) {
  await db().from("birthdays").upsert(
    {
      tg_id: tgId,
      birth_year: year,
      birth_month: month,
      birth_day: day,
      updated_at: new Date().toISOString(),
    },
    { onConflict: "tg_id" },
  );
}

/* -------------------------------- premium -------------------------------- */

export async function isPremium(tgId: number): Promise<boolean> {
  const { data } = await db().from("premium").select("active").eq("tg_id", tgId).maybeSingle();
  return Boolean(data?.active);
}

export async function grantPremium(tgId: number, adminId: number) {
  const { error } = await db().from("premium").upsert(
    {
      tg_id: tgId,
      active: true,
      granted_at: new Date().toISOString(),
      revoked_at: null,
      granted_by: adminId,
      updated_at: new Date().toISOString(),
    },
    { onConflict: "tg_id" },
  );
  if (error) throw error;
}

export async function revokePremium(tgId: number, adminId: number) {
  await db()
    .from("premium")
    .update({
      active: false,
      revoked_at: new Date().toISOString(),
      revoked_by: adminId,
      updated_at: new Date().toISOString(),
    })
    .eq("tg_id", tgId);
}

export async function listPremium() {
  const { data } = await db()
    .from("premium")
    .select("tg_id, granted_at")
    .eq("active", true)
    .order("granted_at", { ascending: false });
  return data ?? [];
}

export async function getPremiumRow(tgId: number) {
  const { data } = await db().from("premium").select("*").eq("tg_id", tgId).maybeSingle();
  return data;
}

/* ------------------------------- reminders ------------------------------- */

export async function saveReminder(tgId: number, text: string) {
  await db()
    .from("reminders")
    .upsert({ tg_id: tgId, text, updated_at: new Date().toISOString() }, { onConflict: "tg_id" });
}

/* ---------------------------- mandatory chats ---------------------------- */

const chatsCache = new Map<string, { at: number; value: any[] }>();
const CHATS_TTL_MS = 30_000;

export function invalidateChatsCache() {
  chatsCache.clear();
}

export async function listChats(activeOnly = true) {
  const key = String(activeOnly);
  const cached = chatsCache.get(key);
  if (cached && Date.now() - cached.at < CHATS_TTL_MS) return cached.value;
  let query = db().from("mandatory_chats").select("*").order("connected_at", { ascending: true });
  if (activeOnly) query = query.eq("active", true);
  const { data } = await query;
  const value = data ?? [];
  chatsCache.set(key, { at: Date.now(), value });
  return value;
}


export async function getChat(chatId: number) {
  const { data } = await db().from("mandatory_chats").select("*").eq("chat_id", chatId).maybeSingle();
  return data;
}

export async function saveChat(row: {
  chat_id: number;
  chat_type: string;
  title: string | null;
  username: string | null;
  invite_link: string | null;
  is_request_based: boolean;
}) {
  await db()
    .from("mandatory_chats")
    .upsert({ ...row, active: true, connected_at: new Date().toISOString() }, { onConflict: "chat_id" });
  invalidateChatsCache();
}

export async function removeChat(chatId: number) {
  await db().from("mandatory_chats").delete().eq("chat_id", chatId);
  invalidateChatsCache();
}

/* ----------------------------- join requests ----------------------------- */

export async function saveJoinRequest(chatId: number, tgId: number) {
  await db()
    .from("join_requests")
    .upsert(
      { chat_id: chatId, tg_id: tgId, status: "pending", requested_at: new Date().toISOString() },
      { onConflict: "chat_id,tg_id" },
    );
}

export async function hasJoinRequest(chatId: number, tgId: number) {
  const { data } = await db()
    .from("join_requests")
    .select("chat_id")
    .eq("chat_id", chatId)
    .eq("tg_id", tgId)
    .maybeSingle();
  return Boolean(data);
}

/* -------------------------------- stats ---------------------------------- */

export async function countUsers() {
  const { count } = await db().from("bot_users").select("tg_id", { count: "exact", head: true });
  return count ?? 0;
}

export async function countPremium() {
  const { count } = await db()
    .from("premium")
    .select("tg_id", { count: "exact", head: true })
    .eq("active", true);
  return count ?? 0;
}

export async function allUserIds(): Promise<number[]> {
  const ids: number[] = [];
  const pageSize = 1000;
  for (let page = 0; ; page++) {
    const { data } = await db()
      .from("bot_users")
      .select("tg_id")
      .range(page * pageSize, page * pageSize + pageSize - 1);
    if (!data || data.length === 0) break;
    ids.push(...data.map((r: any) => Number(r.tg_id)));
    if (data.length < pageSize) break;
  }
  return ids;
}

/* ----------------------------- broadcast logs ---------------------------- */

export async function startBroadcast(adminId: number, message: Record<string, unknown>) {
  const { data } = await db()
    .from("broadcast_logs")
    .insert({ admin_id: adminId, message })
    .select("id")
    .single();
  return data?.id as string | undefined;
}

export async function finishBroadcast(id: string | undefined, sent: number, failed: number) {
  if (!id) return;
  await db()
    .from("broadcast_logs")
    .update({ completed_at: new Date().toISOString(), sent_count: sent, failed_count: failed })
    .eq("id", id);
}

/* --------------------------- daily reminders ----------------------------- */

export async function birthdaysOn(month: number, day: number) {
  const { data } = await db()
    .from("birthdays")
    .select("tg_id, birth_year")
    .eq("birth_month", month)
    .eq("birth_day", day);
  return data ?? [];
}

export async function getReminder(tgId: number) {
  const { data } = await db().from("reminders").select("text").eq("tg_id", tgId).maybeSingle();
  return (data?.text as string | undefined) ?? null;
}

/* --------------------- premium template selection ------------------------ */

export async function getPremiumInfo(tgId: number) {
  const { data } = await db()
    .from("premium")
    .select("active, selected_template_id")
    .eq("tg_id", tgId)
    .maybeSingle();
  return {
    active: Boolean(data?.active),
    selected_template_id: (data?.selected_template_id as number | null) ?? null,
  };
}

export async function setSelectedTemplate(tgId: number, templateId: number) {
  await db()
    .from("premium")
    .update({ selected_template_id: templateId, updated_at: new Date().toISOString() })
    .eq("tg_id", tgId);
}

/* ------------------------- notification dedup ---------------------------- */

/** Returns true when this (user, kind, date) was not logged before. */
/**
 * Claim a (user, kind, date) slot. Returns true if this run should send.
 * A claim that was never confirmed as sent (e.g. the run was killed) is
 * re-claimable after 5 minutes, so interrupted runs are retried without duplicates.
 */
export async function claimNotification(tgId: number, kind: string, sendDate: string) {
  const { error } = await db()
    .from("notification_log")
    .insert({ tg_id: tgId, kind, send_date: sendDate });
  if (!error) return true;
  const staleBefore = new Date(Date.now() - 5 * 60 * 1000).toISOString();
  const { data } = await db()
    .from("notification_log")
    .update({ created_at: new Date().toISOString() })
    .eq("tg_id", tgId)
    .eq("kind", kind)
    .eq("send_date", sendDate)
    .is("sent_at", null)
    .lt("created_at", staleBefore)
    .select("tg_id");
  return Boolean(data && data.length > 0);
}

export async function markNotificationSent(tgId: number, kind: string, sendDate: string) {
  await db()
    .from("notification_log")
    .update({ sent_at: new Date().toISOString() })
    .eq("tg_id", tgId)
    .eq("kind", kind)
    .eq("send_date", sendDate);
}

export async function releaseNotification(tgId: number, kind: string, sendDate: string) {
  await db()
    .from("notification_log")
    .delete()
    .eq("tg_id", tgId)
    .eq("kind", kind)
    .eq("send_date", sendDate);
}

/* ------------------------------ life checks ------------------------------ */

export async function createLifeCheck(tgId: number, checkDate: string, messageId: number | null) {
  await db()
    .from("life_checks")
    .upsert({ tg_id: tgId, check_date: checkDate, message_id: messageId }, { onConflict: "tg_id,check_date" });
}

export async function getLifeCheck(tgId: number, checkDate: string) {
  const { data } = await db()
    .from("life_checks")
    .select("*")
    .eq("tg_id", tgId)
    .eq("check_date", checkDate)
    .maybeSingle();
  return data;
}

/** Records the answer only if none exists yet; returns true when accepted. */
export async function answerLifeCheck(tgId: number, checkDate: string, answer: string) {
  const { data } = await db()
    .from("life_checks")
    .update({ answer, answered_at: new Date().toISOString() })
    .eq("tg_id", tgId)
    .eq("check_date", checkDate)
    .is("answer", null)
    .select("tg_id");
  return Boolean(data && data.length > 0);
}

/* --------------------------- bulk birthday reads -------------------------- */

export type BirthdayRow = {
  tg_id: number;
  birth_year: number;
  birth_month: number;
  birth_day: number;
};

/** Every stored birthday joined with premium status in two queries total. */
export async function allBirthdaysWithPremium() {
  const rows: BirthdayRow[] = [];
  const pageSize = 1000;
  for (let page = 0; ; page++) {
    const { data } = await db()
      .from("birthdays")
      .select("tg_id, birth_year, birth_month, birth_day")
      .range(page * pageSize, page * pageSize + pageSize - 1);
    if (!data || data.length === 0) break;
    rows.push(...(data as any as BirthdayRow[]));
    if (data.length < pageSize) break;
  }

  const { data: premiumRows } = await db()
    .from("premium")
    .select("tg_id, selected_template_id")
    .eq("active", true);
  const premium = new Map<number, number | null>();
  for (const p of premiumRows ?? []) {
    premium.set(Number((p as any).tg_id), ((p as any).selected_template_id as number | null) ?? null);
  }

  return rows.map((r) => ({
    tg_id: Number(r.tg_id),
    birth_year: Number(r.birth_year),
    birth_month: Number(r.birth_month),
    birth_day: Number(r.birth_day),
    premium: premium.has(Number(r.tg_id)),
    selected_template_id: premium.get(Number(r.tg_id)) ?? null,
  }));
}

/** Active premium user ids. */
export async function activePremiumIds(): Promise<number[]> {
  const { data } = await db().from("premium").select("tg_id").eq("active", true);
  return (data ?? []).map((r: any) => Number(r.tg_id));
}
