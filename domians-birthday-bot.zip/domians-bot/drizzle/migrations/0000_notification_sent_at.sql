ALTER TABLE public.notification_log ADD COLUMN IF NOT EXISTS sent_at timestamptz;
UPDATE public.notification_log SET sent_at = created_at WHERE NOT (kind = 'daily' AND send_date = '2026-10-10');