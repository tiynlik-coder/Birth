ALTER TABLE public.premium ADD COLUMN IF NOT EXISTS selected_template_id integer;

CREATE TABLE IF NOT EXISTS public.notification_log (
  tg_id bigint NOT NULL,
  kind text NOT NULL,
  send_date date NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tg_id, kind, send_date)
);
GRANT ALL ON public.notification_log TO service_role;
ALTER TABLE public.notification_log ENABLE ROW LEVEL SECURITY;

CREATE TABLE IF NOT EXISTS public.life_checks (
  tg_id bigint NOT NULL,
  check_date date NOT NULL,
  message_id bigint,
  answer text,
  answered_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tg_id, check_date)
);
GRANT ALL ON public.life_checks TO service_role;
ALTER TABLE public.life_checks ENABLE ROW LEVEL SECURITY;