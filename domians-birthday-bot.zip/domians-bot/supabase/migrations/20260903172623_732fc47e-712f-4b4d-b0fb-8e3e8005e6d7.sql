
CREATE TABLE public.bot_users (
  tg_id bigint PRIMARY KEY,
  username text,
  first_name text,
  last_name text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.bot_users TO service_role;
ALTER TABLE public.bot_users ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.birthdays (
  tg_id bigint PRIMARY KEY,
  birth_year int NOT NULL,
  birth_month int NOT NULL,
  birth_day int NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.birthdays TO service_role;
ALTER TABLE public.birthdays ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.premium (
  tg_id bigint PRIMARY KEY,
  active boolean NOT NULL DEFAULT true,
  granted_at timestamptz,
  revoked_at timestamptz,
  granted_by bigint,
  revoked_by bigint,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.premium TO service_role;
ALTER TABLE public.premium ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.reminders (
  tg_id bigint PRIMARY KEY,
  text text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.reminders TO service_role;
ALTER TABLE public.reminders ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.mandatory_chats (
  chat_id bigint PRIMARY KEY,
  chat_type text NOT NULL,
  title text,
  username text,
  invite_link text,
  is_request_based boolean NOT NULL DEFAULT false,
  active boolean NOT NULL DEFAULT true,
  connected_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.mandatory_chats TO service_role;
ALTER TABLE public.mandatory_chats ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.join_requests (
  chat_id bigint NOT NULL,
  tg_id bigint NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  requested_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (chat_id, tg_id)
);
GRANT ALL ON public.join_requests TO service_role;
ALTER TABLE public.join_requests ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.broadcast_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id bigint NOT NULL,
  message jsonb,
  started_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz,
  sent_count int NOT NULL DEFAULT 0,
  failed_count int NOT NULL DEFAULT 0
);
GRANT ALL ON public.broadcast_logs TO service_role;
ALTER TABLE public.broadcast_logs ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.bot_states (
  tg_id bigint PRIMARY KEY,
  state text,
  data jsonb NOT NULL DEFAULT '{}'::jsonb,
  message_id bigint,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.bot_states TO service_role;
ALTER TABLE public.bot_states ENABLE ROW LEVEL SECURITY;
